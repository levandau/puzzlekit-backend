import { Request, Response, NextFunction } from 'express';
import { ApiResponse } from '../types';

interface RateLimit {
  count: number;
  resetTime: number;
}

const clients = new Map<string, RateLimit>();

const createSimpleRateLimit = (windowMs: number, max: number) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    const clientId = req.ip || 'anonymous';
    const now = Date.now();
    
    // Clean up old entries
    for (const [key, value] of clients.entries()) {
      if (now > value.resetTime) {
        clients.delete(key);
      }
    }
    
    const client = clients.get(clientId);
    
    if (!client || now > client.resetTime) {
      // New window
      clients.set(clientId, {
        count: 1,
        resetTime: now + windowMs
      });
      next();
      return;
    }
    
    if (client.count >= max) {
      // Rate limit exceeded
      const resetIn = Math.ceil((client.resetTime - now) / 1000);
      res.set('Retry-After', String(resetIn));
      res.status(429).json({
        success: false,
        error: 'Too many requests, please try again later',
        retryAfter: resetIn
      } as ApiResponse);
      return;
    }
    
    // Increment count
    client.count++;
    next();
  };
};

// Export rate limiters
export const rateLimitMiddleware = createSimpleRateLimit(15 * 60 * 1000, 100); // 100 requests per 15 minutes
export const authRateLimitMiddleware = createSimpleRateLimit(15 * 60 * 1000, 5); // 5 requests per 15 minutes
export const generationRateLimitMiddleware = createSimpleRateLimit(5 * 60 * 1000, 10); // 10 requests per 5 minutes
