export type PuzzleType = 'sudoku' | 'wordsearch' | 'maze' | 'nonogram';
export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type BookSize = '8.5x11' | '8x10' | '6x9';
export type AnswersMode = 'at_end' | 'per_section';
export type ExportFormat = 'pdf' | 'png' | 'svg' | 'zip';

export interface User {
  _id: string;
  name: string;
  email: string;
  password: string;
  isVerified: boolean;
  subscription: {
    type: 'free' | 'premium' | 'pro';
    expiresAt?: Date;
    stripeCustomerId?: string;
  };
  usage: {
    puzzlesGenerated: number;
    booksCreated: number;
    lastReset: Date;
  };
  preferences: {
    defaultLayout: 1 | 2 | 4;
    defaultSize: BookSize;
    defaultMargins: boolean;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Puzzle {
  _id: string;
  id: string; // Frontend ID
  userId: string;
  type: PuzzleType;
  puzzleSvg: string;
  solutionSvg: string;
  thumbnailUrl?: string;
  meta: {
    seed?: number;
    difficulty?: Difficulty;
    algorithm?: string;
    gridSize?: string;
    customData?: Record<string, any>;
  };
  tags: string[];
  isPublic: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface BookPage {
  id: string;
  puzzles: (string | null)[]; // Puzzle IDs
  layout: 1 | 2 | 4;
}

export interface BookSettings {
  kdpSize: BookSize;
  pageNumbers: boolean;
  margins: boolean;
  answersMode: AnswersMode;
  footerCopyright: string;
  title?: string;
  subtitle?: string;
  author?: string;
}

export interface Book {
  _id: string;
  userId: string;
  title: string;
  description?: string;
  pages: BookPage[];
  settings: BookSettings;
  status: 'draft' | 'published' | 'archived';
  isPublic: boolean;
  exportHistory: {
    format: ExportFormat;
    downloadUrl?: string;
    createdAt: Date;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

export interface PuzzleTemplate {
  _id: string;
  name: string;
  type: PuzzleType;
  description: string;
  thumbnailUrl: string;
  template: Record<string, any>;
  difficulty: Difficulty;
  tags: string[];
  isOfficial: boolean;
  createdBy?: string;
  downloads: number;
  rating: number;
  createdAt: Date;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface AuthResponse {
  user: Omit<User, 'password'>;
  token: string;
  refreshToken: string;
}

export interface CreatePuzzleRequest {
  type: PuzzleType;
  puzzleSvg: string;
  solutionSvg: string;
  meta: Record<string, any>;
  tags?: string[];
  isPublic?: boolean;
}

export interface CreateBookRequest {
  title: string;
  description?: string;
  settings: BookSettings;
  isPublic?: boolean;
}
