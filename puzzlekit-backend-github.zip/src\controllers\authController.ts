import { Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models';
import { config } from '../config/config';
import { ApiResponse, AuthResponse, LoginRequest, RegisterRequest } from '../types';

const generateTokens = (userId: string) => {
  const token = jwt.sign({ userId }, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES_IN
  });
  
  const refreshToken = jwt.sign({ userId }, config.JWT_SECRET, {
    expiresIn: config.JWT_REFRESH_EXPIRES_IN
  });

  return { token, refreshToken };
};

export const register = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, email, password }: RegisterRequest = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser) {
      res.status(400).json({
        success: false,
        error: 'User with this email already exists'
      } as ApiResponse);
      return;
    }

    // Create new user
    const user = new User({
      name,
      email,
      password
    });

    await user.save();

    // Generate tokens
    const { token, refreshToken } = generateTokens(String(user.id));

    // Prepare response
    const userResponse = user.toJSON();
    
    res.status(201).json({
      success: true,
      data: {
        user: userResponse,
        token,
        refreshToken
      },
      message: 'User registered successfully'
    });

  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password }: LoginRequest = req.body;

    // Find user with password (Sequelize includes password by default)
    const user = await User.findOne({ where: { email } });
    if (!user) {
      res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      } as ApiResponse);
      return;
    }

    // Check password
    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      res.status(401).json({
        success: false,
        error: 'Invalid credentials'
      } as ApiResponse);
      return;
    }

    // Reset monthly usage if needed
    user.resetMonthlyUsage();
    await user.save();

    // Generate tokens
    const { token, refreshToken } = generateTokens(String(user.id));

    // Prepare response
    const userResponse = user.toJSON();

    res.json({
      success: true,
      data: {
        user: userResponse,
        token,
        refreshToken
      },
      message: 'Login successful'
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const refreshToken = async (req: Request, res: Response): Promise<void> => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      res.status(401).json({
        success: false,
        error: 'Refresh token required'
      } as ApiResponse);
      return;
    }

    // Verify refresh token
    const decoded = jwt.verify(refreshToken, config.JWT_SECRET) as { userId: string };
    const user = await User.findByPk(decoded.userId);

    if (!user) {
      res.status(401).json({
        success: false,
        error: 'Invalid refresh token'
      } as ApiResponse);
      return;
    }

    // Generate new tokens
    const tokens = generateTokens(String(user.id));

    res.json({
      success: true,
      data: tokens,
      message: 'Token refreshed successfully'
    } as ApiResponse);

  } catch (error) {
    console.error('Refresh token error:', error);
    res.status(401).json({
      success: false,
      error: 'Invalid refresh token'
    } as ApiResponse);
  }
};

export const getProfile = async (req: any, res: Response): Promise<void> => {
  try {
    const user = req.user;
    
    res.json({
      success: true,
      data: user.toJSON(),
      message: 'Profile retrieved successfully'
    } as ApiResponse);

  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const updateProfile = async (req: any, res: Response): Promise<void> => {
  try {
    const userId = req.user._id;
    const { name, preferences } = req.body;

    const updateData: any = {};
    if (name) updateData.name = name;
    if (preferences) updateData.preferences = { ...req.user.preferences, ...preferences };

    const user = await User.findByPk(userId);
    if (user) {
      await user.update(updateData);
    }

    res.json({
      success: true,
      data: user?.toJSON(),
      message: 'Profile updated successfully'
    } as ApiResponse);

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};
