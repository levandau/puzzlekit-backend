import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models';
import { config } from '../config/config';
import { ApiResponse } from '../types';

export interface AuthRequest extends Request {
  user?: any;
}

export const authenticateToken = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({
        success: false,
        error: 'Access token required'
      } as ApiResponse);
      return;
    }

    const decoded = jwt.verify(token, config.JWT_SECRET) as { userId: string };
    const user = await User.findByPk(decoded.userId);

    if (!user) {
      res.status(401).json({
        success: false,
        error: 'Invalid token'
      } as ApiResponse);
      return;
    }

    req.user = user;
    next();
  } catch (error) {
    console.error('Auth error:', error);
    res.status(401).json({
      success: false,
      error: 'Invalid token'
    } as ApiResponse);
  }
};

export const optionalAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
      const decoded = jwt.verify(token, config.JWT_SECRET) as { userId: string };
      const user = await User.findByPk(decoded.userId);
      if (user) {
        req.user = user;
      }
    }
    next();
  } catch (error) {
    // Continue without authentication
    next();
  }
};

export const requireSubscription = (requiredLevel: 'premium' | 'pro') => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    const user = req.user;
    
    if (!user) {
      res.status(401).json({
        success: false,
        error: 'Authentication required'
      } as ApiResponse);
      return;
    }

    const subscriptionHierarchy: Record<string, number> = { free: 0, premium: 1, pro: 2 };
    const userLevel = subscriptionHierarchy[user.subscription.type] || 0;
    const requiredLevelNum = subscriptionHierarchy[requiredLevel] || 0;

    if (userLevel < requiredLevelNum) {
      res.status(403).json({
        success: false,
        error: `${requiredLevel} subscription required`
      } as ApiResponse);
      return;
    }

    // Check if subscription has expired
    if (user.subscription.expiresAt && new Date() > user.subscription.expiresAt) {
      res.status(403).json({
        success: false,
        error: 'Subscription has expired'
      } as ApiResponse);
      return;
    }

    next();
  };
};
