import { Router } from 'express';
import authRoutes from './auth';
import puzzleRoutes from './puzzles';
import bookRoutes from './books';
import templateRoutes from './templates';

const router = Router();

// Health check
router.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'PuzzleKit API is running',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// API routes
router.use('/auth', authRoutes);
router.use('/puzzles', puzzleRoutes);
router.use('/books', bookRoutes);
router.use('/templates', templateRoutes);

export default router;
