import { Request, Response } from 'express';
import { Book } from '../models';
import { ApiResponse, CreateBookRequest } from '../types';
import { AuthRequest } from '../middleware/auth';

export const createBook = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user.id;
    const bookData: CreateBookRequest = req.body;

    const defaultPages = [{
      id: `page_${Date.now()}`,
      layout: 1,
      puzzles: [null]
    }];

    const book = await Book.create({
      userId,
      title: bookData.title,
      description: bookData.description,
      pages: JSON.stringify(defaultPages),
      settingsKdpSize: bookData.settings.kdpSize,
      settingsPageNumbers: bookData.settings.pageNumbers,
      settingsMargins: bookData.settings.margins,
      settingsAnswersMode: bookData.settings.answersMode,
      settingsFooterCopyright: bookData.settings.footerCopyright,
      settingsTitle: bookData.settings.title,
      settingsSubtitle: bookData.settings.subtitle,
      settingsAuthor: bookData.settings.author,
      isPublic: bookData.isPublic || false
    });

    // Update user usage
    const user = req.user;
    user.booksCreated += 1;
    await user.save();

    res.status(201).json({
      success: true,
      data: book,
      message: 'Book created successfully'
    } as ApiResponse);

  } catch (error) {
    console.error('Create book error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const getBooks = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;

    const offset = (page - 1) * limit;
    const { rows: books, count: total } = await Book.findAndCountAll({
      where: { userId },
      order: [['updatedAt', 'DESC']],
      offset,
      limit
    });

    res.json({
      success: true,
      data: books,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    } as ApiResponse);

  } catch (error) {
    console.error('Get books error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const getBook = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const updateBook = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const deleteBook = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const addBookPage = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const updateBookPage = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const deleteBookPage = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};