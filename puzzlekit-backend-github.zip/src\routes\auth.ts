import { Router } from 'express';
import { authController } from '../controllers';
import {
  registerValidation,
  loginValidation,
  authenticateToken,
  authRateLimitMiddleware
} from '../middleware';

const router = Router();

// Apply rate limiting to all auth routes
router.use(authRateLimitMiddleware);

// Public routes
router.post('/register', registerValidation, authController.register);
router.post('/login', loginValidation, authController.login);
router.post('/refresh-token', authController.refreshToken);

// Protected routes
router.get('/profile', authenticateToken, authController.getProfile);
router.put('/profile', authenticateToken, authController.updateProfile);

export default router;
