import { DataTypes, Model, Optional } from 'sequelize';
import bcrypt from 'bcryptjs';
import { sequelize } from '../config/database';
import { config } from '../config/config';

interface UserAttributes {
  id: number;
  name: string;
  email: string;
  password: string;
  isVerified: boolean;
  subscriptionType: 'free' | 'premium' | 'pro';
  subscriptionExpiresAt?: Date;
  stripeCustomerId?: string;
  puzzlesGenerated: number;
  booksCreated: number;
  usageLastReset: Date;
  defaultLayout: 1 | 2 | 4;
  defaultSize: '8.5x11' | '8x10' | '6x9';
  defaultMargins: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

interface UserCreationAttributes extends Optional<UserAttributes, 'id' | 'isVerified' | 'subscriptionType' | 'puzzlesGenerated' | 'booksCreated' | 'usageLastReset' | 'defaultLayout' | 'defaultSize' | 'defaultMargins' | 'createdAt' | 'updatedAt'> {}

export class User extends Model<UserAttributes, UserCreationAttributes> implements UserAttributes {
  public id!: number;
  public name!: string;
  public email!: string;
  public password!: string;
  public isVerified!: boolean;
  public subscriptionType!: 'free' | 'premium' | 'pro';
  public subscriptionExpiresAt?: Date;
  public stripeCustomerId?: string;
  public puzzlesGenerated!: number;
  public booksCreated!: number;
  public usageLastReset!: Date;
  public defaultLayout!: 1 | 2 | 4;
  public defaultSize!: '8.5x11' | '8x10' | '6x9';
  public defaultMargins!: boolean;

  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  // Instance methods
  public async comparePassword(candidatePassword: string): Promise<boolean> {
    return bcrypt.compare(candidatePassword, this.password);
  }

  public resetMonthlyUsage(): void {
    const now = new Date();
    const lastReset = new Date(this.usageLastReset);
    
    // Check if it's a new month
    if (now.getMonth() !== lastReset.getMonth() || now.getFullYear() !== lastReset.getFullYear()) {
      this.puzzlesGenerated = 0;
      this.booksCreated = 0;
      this.usageLastReset = now;
    }
  }

  public override toJSON(): any {
    const values = super.toJSON();
    const { password, ...rest } = values;
    return rest;
  }
}

User.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING(50),
    allowNull: false,
    validate: {
      len: [2, 50]
    }
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: {
      isEmail: true
    }
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [6, 255]
    }
  },
  isVerified: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  subscriptionType: {
    type: DataTypes.ENUM('free', 'premium', 'pro'),
    defaultValue: 'free'
  },
  subscriptionExpiresAt: {
    type: DataTypes.DATE,
    allowNull: true
  },
  stripeCustomerId: {
    type: DataTypes.STRING,
    allowNull: true
  },
  puzzlesGenerated: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  booksCreated: {
    type: DataTypes.INTEGER,
    defaultValue: 0
  },
  usageLastReset: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  defaultLayout: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
    validate: {
      isIn: [[1, 2, 4]]
    }
  },
  defaultSize: {
    type: DataTypes.ENUM('8.5x11', '8x10', '6x9'),
    defaultValue: '8.5x11'
  },
  defaultMargins: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  }
}, {
  sequelize,
  modelName: 'User',
  tableName: 'users',
  indexes: [
    {
      unique: true,
      fields: ['email']
    }
  ],
  hooks: {
    beforeCreate: async (user: User) => {
      if (user.password) {
        user.password = await bcrypt.hash(user.password, config.BCRYPT_ROUNDS);
      }
    },
    beforeUpdate: async (user: User) => {
      if (user.changed('password')) {
        user.password = await bcrypt.hash(user.password, config.BCRYPT_ROUNDS);
      }
    }
  }
});