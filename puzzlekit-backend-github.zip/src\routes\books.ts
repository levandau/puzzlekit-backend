import { Router } from 'express';
import { bookController } from '../controllers';
import {
  authenticateToken,
  createBookValidation,
  paginationValidation,
  mongoIdValidation
} from '../middleware';

const router = Router();

// All routes require authentication
router.use(authenticateToken);

// Book CRUD operations
router.post('/', createBookValidation, bookController.createBook);
router.get('/', paginationValidation, bookController.getBooks);
router.get('/:id', mongoIdValidation('id'), bookController.getBook);
router.put('/:id', mongoIdValidation('id'), bookController.updateBook);
router.delete('/:id', mongoIdValidation('id'), bookController.deleteBook);

// Page management
router.post('/:id/pages', mongoIdValidation('id'), bookController.addBookPage);
router.put('/:id/pages/:pageId', mongoIdValidation('id'), bookController.updateBookPage);
router.delete('/:id/pages/:pageId', mongoIdValidation('id'), bookController.deleteBookPage);

export default router;
