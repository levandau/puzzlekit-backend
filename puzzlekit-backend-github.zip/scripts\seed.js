#!/usr/bin/env node

require('dotenv').config();
const mongoose = require('mongoose');

// Sample data
const sampleTemplates = [
  {
    name: 'Classic Sudoku',
    type: 'sudoku',
    description: 'Traditional 9x9 Sudoku puzzle with medium difficulty',
    thumbnailUrl: 'https://via.placeholder.com/200x200/blue/white?text=Sudoku',
    template: {
      gridSize: '9x9',
      difficulty: 'Medium',
      algorithm: 'backtracking'
    },
    difficulty: 'Medium',
    tags: ['classic', 'numbers', 'logic'],
    isOfficial: true,
    downloads: 150,
    rating: 4.5
  },
  {
    name: 'Simple Maze',
    type: 'maze',
    description: 'Easy maze perfect for beginners',
    thumbnailUrl: 'https://via.placeholder.com/200x200/green/white?text=Maze',
    template: {
      rows: 15,
      cols: 15,
      algorithm: 'prim',
      braid: 0.15
    },
    difficulty: 'Easy',
    tags: ['paths', 'easy', 'beginner'],
    isOfficial: true,
    downloads: 89,
    rating: 4.2
  },
  {
    name: 'Word Search - Animals',
    type: 'wordsearch',
    description: 'Fun word search with animal names',
    thumbnailUrl: 'https://via.placeholder.com/200x200/orange/white?text=Words',
    template: {
      gridSize: '15x15',
      wordList: ['CAT', 'DOG', 'BIRD', 'FISH', 'LION', 'TIGER'],
      directions: ['horizontal', 'vertical', 'diagonal']
    },
    difficulty: 'Easy',
    tags: ['words', 'animals', 'vocabulary'],
    isOfficial: true,
    downloads: 203,
    rating: 4.7
  },
  {
    name: 'Pixel Art Nonogram',
    type: 'nonogram',
    description: 'Create beautiful pixel art while solving puzzles',
    thumbnailUrl: 'https://via.placeholder.com/200x200/purple/white?text=Pixel',
    template: {
      gridSize: '20x20',
      style: 'pixel-art',
      theme: 'nature'
    },
    difficulty: 'Hard',
    tags: ['pixel-art', 'visual', 'creative'],
    isOfficial: true,
    downloads: 67,
    rating: 4.9
  }
];

async function seedDatabase() {
  try {
    console.log('🌱 Seeding database with sample data...');
    
    // Connect to MongoDB
    const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/puzzlekit';
    await mongoose.connect(mongoUri);
    console.log('✅ Connected to MongoDB');

    // Import models
    const { PuzzleTemplate } = require('../dist/models');

    // Clear existing templates
    await PuzzleTemplate.deleteMany({ isOfficial: true });
    console.log('🧹 Cleared existing official templates');

    // Insert sample templates
    const templates = await PuzzleTemplate.insertMany(sampleTemplates);
    console.log(`✅ Created ${templates.length} sample templates`);

    console.log('\n🎉 Database seeded successfully!');
    console.log('Sample templates available at: GET /api/v1/templates');
    
  } catch (error) {
    console.error('❌ Seeding failed:', error);
  } finally {
    await mongoose.connection.close();
    console.log('📦 Database connection closed');
    process.exit(0);
  }
}

seedDatabase();
