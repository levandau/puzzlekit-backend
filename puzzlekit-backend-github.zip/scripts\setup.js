#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

console.log('🚀 Setting up PuzzleKit Backend...\n');

// Create necessary directories
const directories = [
  'uploads',
  'logs',
  'dist'
];

directories.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
    console.log(`✅ Created directory: ${dir}`);
  } else {
    console.log(`📁 Directory already exists: ${dir}`);
  }
});

// Copy environment file if it doesn't exist
const envExample = 'env.example';
const envFile = '.env';

if (!fs.existsSync(envFile)) {
  if (fs.existsSync(envExample)) {
    fs.copyFileSync(envExample, envFile);
    console.log('✅ Created .env file from env.example');
    console.log('⚠️  Please update the .env file with your configuration');
  } else {
    console.log('❌ env.example file not found');
  }
} else {
  console.log('📄 .env file already exists');
}

// Check if MongoDB is running
try {
  execSync('mongosh --eval "db.runCommand({connectionStatus: 1})"', { stdio: 'ignore' });
  console.log('✅ MongoDB is running');
} catch (error) {
  console.log('⚠️  MongoDB might not be running. Please ensure MongoDB is installed and running.');
  console.log('   Download from: https://www.mongodb.com/try/download/community');
}

console.log('\n🎉 Setup completed!');
console.log('\n📋 Next steps:');
console.log('1. Update your .env file with the correct configuration');
console.log('2. Install dependencies: npm install');
console.log('3. Start development server: npm run dev');
console.log('4. Test the API: npm test');
console.log('\n🔗 API will be available at: http://localhost:5000/api/v1');
