import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from '../config/database';

interface PuzzleAttributes {
  id: number;
  frontendId: string;
  userId: number;
  type: 'sudoku' | 'wordsearch' | 'maze' | 'nonogram';
  puzzleSvg: string;
  solutionSvg: string;
  thumbnailUrl?: string;
  metaSeed?: number;
  metaDifficulty?: 'Easy' | 'Medium' | 'Hard';
  metaAlgorithm?: string;
  metaGridSize?: string;
  metaCustomData?: string; // JSON string
  tags: string; // JSON array as string
  isPublic: boolean;
  createdAt?: Date;
  updatedAt?: Date;
}

interface PuzzleCreationAttributes extends Optional<PuzzleAttributes, 'id' | 'isPublic' | 'createdAt' | 'updatedAt'> {}

export class Puzzle extends Model<PuzzleAttributes, PuzzleCreationAttributes> implements PuzzleAttributes {
  public id!: number;
  public frontendId!: string;
  public userId!: number;
  public type!: 'sudoku' | 'wordsearch' | 'maze' | 'nonogram';
  public puzzleSvg!: string;
  public solutionSvg!: string;
  public thumbnailUrl?: string;
  public metaSeed?: number;
  public metaDifficulty?: 'Easy' | 'Medium' | 'Hard';
  public metaAlgorithm?: string;
  public metaGridSize?: string;
  public metaCustomData?: string;
  public tags!: string;
  public isPublic!: boolean;

  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  // Helper methods for JSON fields
  public getTagsArray(): string[] {
    try {
      return JSON.parse(this.tags || '[]');
    } catch {
      return [];
    }
  }

  public setTagsArray(tags: string[]): void {
    this.tags = JSON.stringify(tags);
  }

  public getMetaCustomDataObj(): any {
    try {
      return JSON.parse(this.metaCustomData || '{}');
    } catch {
      return {};
    }
  }

  public setMetaCustomDataObj(data: any): void {
    this.metaCustomData = JSON.stringify(data);
  }
}

Puzzle.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  frontendId: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  type: {
    type: DataTypes.ENUM('sudoku', 'wordsearch', 'maze', 'nonogram'),
    allowNull: false
  },
  puzzleSvg: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  solutionSvg: {
    type: DataTypes.TEXT('long'),
    allowNull: false
  },
  thumbnailUrl: {
    type: DataTypes.STRING,
    allowNull: true
  },
  metaSeed: {
    type: DataTypes.INTEGER,
    allowNull: true
  },
  metaDifficulty: {
    type: DataTypes.ENUM('Easy', 'Medium', 'Hard'),
    allowNull: true
  },
  metaAlgorithm: {
    type: DataTypes.STRING,
    allowNull: true
  },
  metaGridSize: {
    type: DataTypes.STRING,
    allowNull: true
  },
  metaCustomData: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  tags: {
    type: DataTypes.TEXT,
    defaultValue: '[]'
  },
  isPublic: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
}, {
  sequelize,
  modelName: 'Puzzle',
  tableName: 'puzzles',
  indexes: [
    {
      fields: ['userId']
    },
    {
      fields: ['type']
    },
    {
      fields: ['isPublic']
    },
    {
      fields: ['metaDifficulty']
    }
  ]
});