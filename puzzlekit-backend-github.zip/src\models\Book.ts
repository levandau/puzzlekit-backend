import { DataTypes, Model, Optional } from 'sequelize';
import { sequelize } from '../config/database';

interface BookAttributes {
  id: number;
  userId: number;
  title: string;
  description?: string;
  pages: string; // JSON string
  settingsKdpSize: '8.5x11' | '8x10' | '6x9';
  settingsPageNumbers: boolean;
  settingsMargins: boolean;
  settingsAnswersMode: 'at_end' | 'per_section';
  settingsFooterCopyright: string;
  settingsTitle?: string;
  settingsSubtitle?: string;
  settingsAuthor?: string;
  status: 'draft' | 'published' | 'archived';
  isPublic: boolean;
  exportHistory: string; // JSON string
  createdAt?: Date;
  updatedAt?: Date;
}

interface BookCreationAttributes extends Optional<BookAttributes, 'id' | 'status' | 'isPublic' | 'exportHistory' | 'createdAt' | 'updatedAt'> {}

export class Book extends Model<BookAttributes, BookCreationAttributes> implements BookAttributes {
  public id!: number;
  public userId!: number;
  public title!: string;
  public description?: string;
  public pages!: string;
  public settingsKdpSize!: '8.5x11' | '8x10' | '6x9';
  public settingsPageNumbers!: boolean;
  public settingsMargins!: boolean;
  public settingsAnswersMode!: 'at_end' | 'per_section';
  public settingsFooterCopyright!: string;
  public settingsTitle?: string;
  public settingsSubtitle?: string;
  public settingsAuthor?: string;
  public status!: 'draft' | 'published' | 'archived';
  public isPublic!: boolean;
  public exportHistory!: string;

  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;

  // Helper methods for JSON fields
  public getPagesArray(): any[] {
    try {
      return JSON.parse(this.pages || '[]');
    } catch {
      return [];
    }
  }

  public setPagesArray(pages: any[]): void {
    this.pages = JSON.stringify(pages);
  }

  public getExportHistoryArray(): any[] {
    try {
      return JSON.parse(this.exportHistory || '[]');
    } catch {
      return [];
    }
  }

  public setExportHistoryArray(history: any[]): void {
    this.exportHistory = JSON.stringify(history);
  }

  public getTotalPuzzles(): number {
    const pages = this.getPagesArray();
    return pages.reduce((total, page) => {
      return total + (page.puzzles || []).filter((p: any) => p !== null).length;
    }, 0);
  }
}

Book.init({
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  title: {
    type: DataTypes.STRING(100),
    allowNull: false,
    validate: {
      len: [1, 100]
    }
  },
  description: {
    type: DataTypes.STRING(500),
    allowNull: true,
    validate: {
      len: [0, 500]
    }
  },
  pages: {
    type: DataTypes.TEXT,
    defaultValue: '[]'
  },
  settingsKdpSize: {
    type: DataTypes.ENUM('8.5x11', '8x10', '6x9'),
    defaultValue: '8.5x11'
  },
  settingsPageNumbers: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  settingsMargins: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  settingsAnswersMode: {
    type: DataTypes.ENUM('at_end', 'per_section'),
    defaultValue: 'at_end'
  },
  settingsFooterCopyright: {
    type: DataTypes.STRING,
    defaultValue: `© ${new Date().getFullYear()} My Puzzle Books`
  },
  settingsTitle: {
    type: DataTypes.STRING,
    allowNull: true
  },
  settingsSubtitle: {
    type: DataTypes.STRING,
    allowNull: true
  },
  settingsAuthor: {
    type: DataTypes.STRING,
    allowNull: true
  },
  status: {
    type: DataTypes.ENUM('draft', 'published', 'archived'),
    defaultValue: 'draft'
  },
  isPublic: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  },
  exportHistory: {
    type: DataTypes.TEXT,
    defaultValue: '[]'
  }
}, {
  sequelize,
  modelName: 'Book',
  tableName: 'books',
  indexes: [
    {
      fields: ['userId']
    },
    {
      fields: ['status']
    },
    {
      fields: ['isPublic']
    }
  ]
});