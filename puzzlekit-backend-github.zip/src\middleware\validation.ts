import { Request, Response, NextFunction } from 'express';
import { body, param, query, validationResult } from 'express-validator';
import { ApiResponse } from '../types';

export const handleValidationErrors = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    res.status(400).json({
      success: false,
      error: 'Validation failed',
      details: errors.array()
    } as ApiResponse);
    return;
  }
  next();
};

// Auth validation rules
export const registerValidation = [
  body('name')
    .trim()
    .isLength({ min: 2, max: 50 })
    .withMessage('Name must be between 2 and 50 characters'),
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long'),
  handleValidationErrors
];

export const loginValidation = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  handleValidationErrors
];

// Puzzle validation rules
export const createPuzzleValidation = [
  body('type')
    .isIn(['sudoku', 'wordsearch', 'maze', 'nonogram'])
    .withMessage('Invalid puzzle type'),
  body('puzzleSvg')
    .notEmpty()
    .withMessage('Puzzle SVG is required'),
  body('solutionSvg')
    .notEmpty()
    .withMessage('Solution SVG is required'),
  body('meta')
    .isObject()
    .withMessage('Meta must be an object'),
  body('tags')
    .optional()
    .isArray()
    .withMessage('Tags must be an array'),
  body('isPublic')
    .optional()
    .isBoolean()
    .withMessage('isPublic must be a boolean'),
  handleValidationErrors
];

// Book validation rules
export const createBookValidation = [
  body('title')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Title must be between 1 and 100 characters'),
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description cannot be longer than 500 characters'),
  body('settings')
    .isObject()
    .withMessage('Settings must be an object'),
  body('settings.kdpSize')
    .isIn(['8.5x11', '8x10', '6x9'])
    .withMessage('Invalid KDP size'),
  body('settings.pageNumbers')
    .isBoolean()
    .withMessage('pageNumbers must be a boolean'),
  body('settings.margins')
    .isBoolean()
    .withMessage('margins must be a boolean'),
  body('settings.answersMode')
    .isIn(['at_end', 'per_section'])
    .withMessage('Invalid answers mode'),
  body('isPublic')
    .optional()
    .isBoolean()
    .withMessage('isPublic must be a boolean'),
  handleValidationErrors
];

// Pagination validation
export const paginationValidation = [
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Page must be a positive integer'),
  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('Limit must be between 1 and 100'),
  handleValidationErrors
];

// ID validation
export const mongoIdValidation = (field: string = 'id') => [
  param(field)
    .isMongoId()
    .withMessage(`Invalid ${field}`),
  handleValidationErrors
];
