import { User } from './User';
import { Puzzle } from './Puzzle';
import { Book } from './Book';

// Define associations
User.hasMany(Puzzle, { foreignKey: 'userId', as: 'puzzles' });
Puzzle.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasMany(Book, { foreignKey: 'userId', as: 'books' });
Book.belongsTo(User, { foreignKey: 'userId', as: 'user' });

export { User, Puzzle, Book };