import { Router } from 'express';
import { templateController } from '../controllers';
import {
  authenticateToken,
  optionalAuth,
  paginationValidation,
  mongoIdValidation
} from '../middleware';

const router = Router();

// Public routes
router.get('/', optionalAuth, paginationValidation, templateController.getTemplates);
router.get('/:id', optionalAuth, mongoIdValidation('id'), templateController.getTemplate);

// Protected routes
router.use(authenticateToken);

router.post('/', templateController.createTemplate);
router.post('/:id/download', mongoIdValidation('id'), templateController.downloadTemplate);
router.post('/:id/rate', mongoIdValidation('id'), templateController.rateTemplate);

export default router;
