import { Router } from 'express';
import { puzzleController } from '../controllers';
import {
  authenticateToken,
  optionalAuth,
  createPuzzleValidation,
  paginationValidation,
  mongoIdValidation,
  generationRateLimitMiddleware
} from '../middleware';

const router = Router();

// Public routes (with optional auth for personalization)
router.get('/public', optionalAuth, paginationValidation, puzzleController.getPublicPuzzles);

// Protected routes
router.use(authenticateToken);

// CRUD operations
router.post('/', generationRateLimitMiddleware, createPuzzleValidation, puzzleController.createPuzzle);
router.get('/', paginationValidation, puzzleController.getPuzzles);
router.get('/:id', mongoIdValidation('id'), puzzleController.getPuzzle);
router.put('/:id', mongoIdValidation('id'), puzzleController.updatePuzzle);
router.delete('/:id', mongoIdValidation('id'), puzzleController.deletePuzzle);

export default router;
