import { Request, Response } from 'express';
import { Puzzle } from '../models';
import { ApiResponse, CreatePuzzleRequest } from '../types';
import { AuthRequest } from '../middleware/auth';

export const createPuzzle = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user.id;
    const puzzleData: CreatePuzzleRequest = req.body;

    // Generate unique frontend ID
    const frontendId = `${puzzleData.type}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const puzzle = await Puzzle.create({
      frontendId,
      userId,
      type: puzzleData.type,
      puzzleSvg: puzzleData.puzzleSvg,
      solutionSvg: puzzleData.solutionSvg,
      metaSeed: puzzleData.meta?.seed,
      metaDifficulty: puzzleData.meta?.difficulty,
      metaAlgorithm: puzzleData.meta?.algorithm,
      metaGridSize: puzzleData.meta?.gridSize,
      metaCustomData: JSON.stringify(puzzleData.meta?.customData || {}),
      tags: JSON.stringify(puzzleData.tags || []),
      isPublic: puzzleData.isPublic || false
    });

    // Update user usage
    const user = req.user;
    user.puzzlesGenerated += 1;
    await user.save();

    res.status(201).json({
      success: true,
      data: puzzle,
      message: 'Puzzle created successfully'
    } as ApiResponse);

  } catch (error) {
    console.error('Create puzzle error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const getPuzzles = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user.id;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const type = req.query.type as string;

    // Build filter
    const where: any = { userId };
    if (type) where.type = type;

    // Execute query with pagination
    const offset = (page - 1) * limit;
    const { rows: puzzles, count: total } = await Puzzle.findAndCountAll({
      where,
      order: [['createdAt', 'DESC']],
      offset,
      limit
    });

    res.json({
      success: true,
      data: puzzles,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    } as ApiResponse);

  } catch (error) {
    console.error('Get puzzles error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const getPuzzle = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const puzzle = await Puzzle.findOne({ 
      where: { 
        id,
        userId 
      }
    });

    if (!puzzle) {
      res.status(404).json({
        success: false,
        error: 'Puzzle not found'
      } as ApiResponse);
      return;
    }

    res.json({
      success: true,
      data: puzzle
    } as ApiResponse);

  } catch (error) {
    console.error('Get puzzle error:', error);
    res.status(500).json({
      success: false,
      error: 'Internal server error'
    } as ApiResponse);
  }
};

export const updatePuzzle = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const deletePuzzle = async (req: AuthRequest, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};

export const getPublicPuzzles = async (req: Request, res: Response): Promise<void> => {
  res.status(501).json({ success: false, error: 'Not implemented yet' });
};