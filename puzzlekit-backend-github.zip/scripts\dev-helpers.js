#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

const commands = {
  setup: () => {
    console.log('🚀 Setting up PuzzleKit Backend...');
    execSync('node scripts/setup.js', { stdio: 'inherit' });
  },

  start: () => {
    console.log('🏃 Starting development server...');
    execSync('npm run dev', { stdio: 'inherit' });
  },

  build: () => {
    console.log('🔨 Building for production...');
    execSync('npm run build', { stdio: 'inherit' });
  },

  seed: () => {
    console.log('🌱 Seeding database...');
    if (!fs.existsSync('dist')) {
      console.log('Building first...');
      execSync('npm run build', { stdio: 'inherit' });
    }
    execSync('node scripts/seed.js', { stdio: 'inherit' });
  },

  test: () => {
    console.log('🧪 Running health checks...');
    try {
      const response = execSync('curl -s http://localhost:5000/api/v1/health', { encoding: 'utf8' });
      const data = JSON.parse(response);
      if (data.success) {
        console.log('✅ API is running successfully!');
        console.log(`📊 Version: ${data.version}`);
        console.log(`⏰ Timestamp: ${data.timestamp}`);
      }
    } catch (error) {
      console.log('❌ API is not running or not responding');
      console.log('💡 Try running: npm run dev');
    }
  },

  mongo: () => {
    console.log('🗄️  Connecting to MongoDB...');
    try {
      execSync('mongosh mongodb://localhost:27017/puzzlekit', { stdio: 'inherit' });
    } catch (error) {
      console.log('❌ MongoDB connection failed');
      console.log('💡 Make sure MongoDB is running: sudo systemctl start mongod');
    }
  },

  logs: () => {
    console.log('📋 Showing recent logs...');
    if (fs.existsSync('logs/app.log')) {
      execSync('tail -f logs/app.log', { stdio: 'inherit' });
    } else {
      console.log('No log file found. Start the server first.');
    }
  },

  clean: () => {
    console.log('🧹 Cleaning build artifacts...');
    if (fs.existsSync('dist')) {
      fs.rmSync('dist', { recursive: true });
      console.log('✅ Cleaned dist folder');
    }
    if (fs.existsSync('node_modules')) {
      console.log('⚠️  Removing node_modules...');
      fs.rmSync('node_modules', { recursive: true });
      console.log('✅ Cleaned node_modules');
    }
  },

  help: () => {
    console.log(`
🛠️  PuzzleKit Backend Development Helpers

Usage: node scripts/dev-helpers.js <command>

Commands:
  setup     Setup environment and directories
  start     Start development server  
  build     Build for production
  seed      Seed database with sample data
  test      Test API health
  mongo     Connect to MongoDB shell
  logs      Show real-time logs
  clean     Clean build artifacts
  help      Show this help message

Examples:
  node scripts/dev-helpers.js setup
  node scripts/dev-helpers.js start
  node scripts/dev-helpers.js test
    `);
  }
};

const command = process.argv[2];

if (!command || !commands[command]) {
  commands.help();
  process.exit(1);
}

commands[command]();
