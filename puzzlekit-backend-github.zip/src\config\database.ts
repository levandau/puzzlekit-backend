import { Sequelize } from 'sequelize';
import { config } from './config';

export const sequelize = new Sequelize({
  dialect: 'mysql',
  host: config.DB_HOST,
  port: config.DB_PORT,
  username: config.DB_USER,
  password: config.DB_PASSWORD,
  database: config.DB_NAME,
  logging: config.NODE_ENV === 'development' ? console.log : false,
  define: {
    timestamps: true,
    underscored: true,
  },
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
});

export const connectDatabase = async (): Promise<void> => {
  try {
    await sequelize.authenticate();
    console.log('✅ MySQL connected successfully');

    // Sync models in development
    if (config.NODE_ENV === 'development') {
      await sequelize.sync({ alter: true });
      console.log('✅ Database synchronized');
    }

    // Note: Sequelize doesn't have .on() method like mongoose

    // Graceful shutdown
    process.on('SIGINT', async () => {
      await sequelize.close();
      console.log('📦 MySQL connection closed through app termination');
      process.exit(0);
    });

  } catch (error) {
    console.error('❌ MySQL connection failed:', error);
    process.exit(1);
  }
};

export const disconnectDatabase = async (): Promise<void> => {
  await sequelize.close();
};